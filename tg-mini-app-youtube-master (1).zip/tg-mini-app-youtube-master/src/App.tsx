import RockPaperScissors from "./components/RockPaperScissors"

function App() {
  return (
    <RockPaperScissors />
  )
}

export default App
